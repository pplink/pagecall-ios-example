//
//  PageCallSDK.h
//  PageCallSDK
//
//  Created by Park Sehun on 31/01/2019.
//  Copyright © 2019 Park Sehun. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for PageCallSDK.
FOUNDATION_EXPORT double PageCallSDKVersionNumber;

//! Project version string for PageCallSDK.
FOUNDATION_EXPORT const unsigned char PageCallSDKVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <PageCallSDK/PublicHeader.h>
#import <PageCallSDK/PageCall.h>

